# -*- coding: utf-8 -*-
from django.http import HttpResponse
import requests
from django.shortcuts import render
import collections
import json
import geocoder
import urllib2
def farm(request):
	r = requests.get('http://127.0.0.1:8000/farms/farmlist')
	cr=requests.get('http://127.0.0.1:8000/farms/croplist')
	j=r.json()
	cr=cr.json()
	farm_id=[]
	h_id=[]
	area=[]
	l1=[]
	l2=[]
	lat=[[]]
	lon=[[]]
	ka=["kjsbdf","sdfds"]
	for a in j:
		farm_id.append(int(a['id']))
		h_id.append(int(a['house_id']))
		area.append(float(a['area']))
		o=a['poly']['coordinates'][0]
		for O in o:
			l2.append(O[0])
			l1.append(O[1])
		lat.append(l1)
		lon.append(l2)
		l1=[]
		l2=[]
	lat.remove([])
	lon.remove([])
	print lat
	print lon
	print farm_id
	print h_id
	print area
	crpa=[[]]
	cr2=[]
	fid=[]
	q=1
	for k in cr:
		if q==1:
			fid.append(k['farm_id'])
			cr2.append(int(k['crop_area']))
			q=2
		else:
			if k['farm_id'] in fid:
				cr2.append(int(k['crop_area']))
			else:	
				crpa.append(cr2)
				fid.append(k['farm_id'])
				cr2=[]
				cr2.append(int(k['crop_area']))
	crpa.append(cr2)
	crpa.remove([])
	print crpa


	alt=[[]]
	for i in range(len(lat)):
		pk=[]
		a1=reduce(lambda x,y:x+y,lat[i])/len(lat[i])
		pk.append(a1)
		b1=reduce(lambda x,y:x+y,lon[i])/len(lon[i])
		pk.append(b1)
		alt.append(pk)
	alt.remove([])
	print alt
	final=[[]]
	for v in range(len(alt)):
		fin=alt[v]+crpa[v]#Add two lists using + operator
		final.append(fin)
	final.remove([])
	print final
	context={'lat':lat,'lon':lon,'farm_id':farm_id,'area':area,'h_id':h_id,'final':final}
	return render(request, 'maps/farm1.html', context)




def house(request):
	r=requests.get('http://127.0.0.1:8000/farms/houselist')
	a=requests.get('http://127.0.0.1:8000/farms/members')
	j=r.json()
	a=a.json()
	house_id=[]
	lat=[]
	lon=[]
	mi=[]
	ml=[]
	links=[]
	for k in j:
		lk=""
		house_id.append(k['id'])
		l1=k['point']['coordinates'][1]
		lat.append(l1)
		l2=k['point']['coordinates'][0]
		lon.append(l2)
		mi.append(k['mon_income'])
		lk='<img src="'+str(k['links'])+'">'
		print lk
		links.append(lk)
	print lat
	print lon
	person_names={}
	person_dob={}
	print links
	for k in a:
		if k['house_id'] in person_names:
			person_names[k['house_id']].append(str(k['name']))
		else:
			person_names[k['house_id']]=[str(k['name'])]
	for k in a:
		if k['house_id'] in person_dob:
			person_dob[k['house_id']].append(str(k['DOB']))
		else:
			person_dob[k['house_id']]=[str(k['DOB'])]
	info=[]
	st=''
	for s in house_id:
		m=person_names[s]
		print m
		g=len(m)
		ml.append(g)
		n=person_dob[s]
		for v in range(len(m)):
			st=st+str(m[v])+' DOB : '+n[v]+'\n'
		info.append(st)
		st=''
	print ml
	print type(links[0])
	context={'lat':lat,'lon':lon,'house_id':house_id,'mi':mi,'info':info,'ml':ml,'links':links}
	return render(request, 'maps/house1.html', context)


def well(request):
	r = requests.get('http://127.0.0.1:8000/farms/farmlist')
	b=requests.get('http://127.0.0.1:8000/farms/welllist')	
	b=b.json()
	j = r.json()
	farm_id=[]
	h_id=[]
	area=[]
	l1=[]
	l2=[]
	lat=[[]]
	lon=[[]]
	ka=["kjsbdf","sdfds"]
	for a in j:
		farm_id.append(int(a['id']))
		h_id.append(int(a['house_id']))
		area.append(float(a['area']))
		o=a['poly']['coordinates'][0]
		for O in o:
			l2.append(O[0])
			l1.append(O[1])
		lat.append(l1)
		lon.append(l2)
		l1=[]
		l2=[]
	lat.remove([])
	lon.remove([])

	lat1=[]
	lon1=[]
	depth=[]
	well_id=[]
	avg_yield=[]
	q=1
	f_id=[]
	#iframe="<iframe src="+"'{% url '3d' %}' width="200" height="200" frameborder="0"></iframe>"
	#print iframe
	for k in b:
		f_id.append(k['farm_id'])
		well_id.append(k['id'])
		lat1.append(float(k['lat']))
		lon1.append(float(k['lon']))
		depth.append(float(k['depth_in_meters']))
		avg_yield.append(float(k['Avg_wateryield']))
	context={'lat':lat,'lon':lon,'farm_id':farm_id,'area':area,'f_id':f_id,'lat1':lat1,'lon1':lon1,'depth':depth,'avg_yield':avg_yield,'well_id':well_id,'house_id':h_id}		
	return render(request, 'maps/well1.html', context)





def index(request):

	gummidipoondi=geocoder.google('Gummidipoondi')
	glat=str(gummidipoondi.lat)
	glon=str(gummidipoondi.lng)
	print glat,glon
	
	url1="https://api.openweathermap.org/data/2.5/weather?lat="+glat+"&lon="+glon+"&APPID=346ba46503e3cd80a9dde36dc27d0974"	
	res = requests.get(url1)
	html=res.json()
	ghum=html['main']['humidity']
	temperature1=float(html['main']['temp'])-273
	gtemp=str(temperature1)
	print ghum,gtemp
	context = {'ghum':ghum,'gtemp':gtemp}
	return render(request, 'maps/index.html',context)
def d3(request):
	return render(request, 'maps/3d.html')


def maps(request):
	return render(request, 'maps/maps.html')






def piechart(request):
	r=requests.get('http://127.0.0.1:8000/farms/farmyield')
	h=requests.get('http://127.0.0.1:8000/farms/houselist')
	o=requests.get('http://127.0.0.1:8000/farms/avgincome')
	j=r.json()
	h=h.json()
	o=o.json()
	farm_id=[]
	Yield=[]
	for k in j:
		farm_id.append(int(k['farm_id']))
		Yield.append(int(k['Yield']))
	#print farm_id
	#print Yield
	pie=[]
	f=['Farm','Yield']
	pie.append(f)
	#pie.remove([])
	g=[]
	for i in range(len(farm_id)):
		l='farm'+str(farm_id[i])
		g.append(l)
		g.append(int(Yield[i]))
		pie.append(g)
		g=[]
	#print pie
	house_id=[]
	mi=[]
	g=[]
	pie1=[]	
	f=['House','Income']
	pie1.append(f)
	for m in h:
		house_id.append(m['id'])
		mi.append(m['mon_income'])
	for i in range(len(house_id)):
		l='House'+str(house_id[i])
		g.append(l)
		g.append(int(mi[i]))
		pie1.append(g)
		g=[]
	#print pie1




	h_id=[]
	year={}
	for d in o:
		if d.get('year') not in year:
			year[d.get('year')]=[d.get('Avg_inc')]
			
		else:
			year[d.get('year')].append(d.get('Avg_inc'))
	keylist=year.keys()
	keylist.sort()
	final11=[]
	for key in keylist:
		print key
		p=[]
		p.append(str(key))
		g=p+year[key]
		final11.append(g)
	print final11
		
	gra=['Year']
	house_id.sort()
	for n in house_id:
		f='house'+str(n)
		gra.append(f)
	print gra
	graph=[]
	graph.append(gra)
	finalgraph= graph+final11
	context={'farm_id':farm_id,'Yield':Yield,'pie':pie,'pie1':pie1,'finalgraph':finalgraph}
	return render(request, 'maps/piechart.html',context)
def contact(request):
	return render(request, 'maps/contact.html')

def carecenters(request):
	r=requests.get('http://127.0.0.1:8000/farms/carecenters')
	care=r.json()
	print care	
	context={'data':care}
	
	return render(request,'maps/carecenters.html',context)


